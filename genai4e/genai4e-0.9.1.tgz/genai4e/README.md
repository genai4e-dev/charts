# Genai4E Helm chart

Genai4E is a self-hosted enterprise AI platform. It gives people governed access to AI models, and it also runs MCP tools, knowledge search (RAG) and agents as apps. Everything runs inside your cluster, and nothing phones home.

## Before you start

- Kubernetes 1.30 or later, with a default StorageClass (or set `storageClass`).
- A hostname for the platform, such as `ai.example.com`. Point its DNS at the edge Service once it has an address.
- About 3 GB of memory for everything, or about 0.7 GB with `sso.enabled=false` and `apps.enabled=false`.
- A network layer that enforces NetworkPolicy (Calico, Cilium, or your cloud's CNI), if you run apps.
- A license file from Genai4E (ask your Genai4E contact; trials are available).

## Install

```bash
helm install genai4e oci://ghcr.io/genai4e-dev/charts/genai4e --version <version> \
  -n genai4e --create-namespace \
  --set hostname=ai.example.com \
  --set adminEmail=you@example.com \
  --set-file license=./acme.lic
```

The chart index works too:

```bash
helm repo add genai4e https://charts.genai4e.com
helm install genai4e genai4e/genai4e -n genai4e --create-namespace --set hostname=… --set adminEmail=… --set-file license=./acme.lic
```

The chart creates the platform's own namespaces (`genai4e-system`, `-edge`, `-git`, `-ci`, `-data`, and the app namespaces `genai4e-apps-mcp`, `-rag`, `-agent`), so install the release into a separate one such as `genai4e`. The notes printed after installing show:

- how to get the first admin's one-time password;
- how to trust the certificate;
- how to back up the encryption key (the KEK). **Do that right away.**

## Common settings

| Value | Default | What it does |
|---|---|---|
| `hostname` | (required) | The address people use: `https://<hostname>`. |
| `adminEmail` | (required) | The first admin's email. |
| `license` | `""` | The license file, passed with `--set-file`. You can also create the Secret yourself: `kubectl -n genai4e-system create secret generic genai4e-license --from-file=value=./acme.lic`. |
| `tls.mode` | `internal` | `internal`: the platform makes its own CA. `files`: you bring the certificate. |
| `tls.cert`, `tls.key` | `""` | Your certificate and key, passed with `--set-file` (implies `files`). Instead, you can provide the Secret `genai4e-edge/genai4e-tls` yourself, for example from cert-manager. |
| `sso.enabled` | `true` | The bundled Keycloak for single sign-on, at `/auth`. |
| `apps.enabled` | `true` | The Git server, the CI launcher (one Job per CI run) and the vector database, for MCP, RAG and agent apps. |
| `edge.serviceType`, `edge.annotations` | `LoadBalancer`, `{}` | How traffic gets in, for example `service.beta.kubernetes.io/aws-load-balancer-type: nlb`. |
| `storageClass`, `storage.*` | cluster default; 5/5/10/10 Gi | Volumes for Postgres, MLflow, Git and vectors. **These can only be set at install.** |
| `images.registry`, `images.tag` | `ghcr.io/genai4e-dev`, the chart's appVersion | Where Genai4E's images come from. Third-party images are under `images.postgres`, `images.pgvector`, `images.traefik` and `images.forgejo`. |
| `imagePullSecrets` | `[]` | For a private mirror. The Secret must exist in each platform namespace. |
| `clusterId` | looked up | What a cluster-bound license is checked against. The default is the `kube-system` namespace's UID. |
| `extraConfig` | `{}` | More `GENAI4E_*` settings. |

## Renew the license

```bash
helm upgrade genai4e oci://ghcr.io/genai4e-dev/charts/genai4e --version <version> -n genai4e \
  --reuse-values --set-file license=./acme-2027.lic
```

The new license applies within about a minute, with no restart. AI requests (`/v1`, `/mcp`) keep working even after a license lapses. Only changes in the Portal are paused.

## Trying it on Docker Desktop (`hostname=localhost`)

App projects need CI to push images to the built-in registry and Kubernetes to pull them. With `hostname=localhost` both would reach `localhost` inside their own pod, so the push fails. The chart has no setting for this yet. On a laptop, apply the source install's workaround (`k8s/overlays/dev`) over the release: the Git server on `localhost:30500` (a NodePort), and a forwarder in each CI job. It drifts from the chart: a `helm upgrade` undoes it, so apply it again after one.

```bash
kubectl -n genai4e-system patch configmap <genai4e-config-…> --type merge   -p '{"data":{"GENAI4E_GIT_WEB_URL":"http://localhost:30500","GENAI4E_REGISTRY_HOST":"localhost:30500"}}'
kubectl -n genai4e-git patch configmap <forgejo-env-…> --type merge -p '{"data":{"FORGEJO__server__ROOT_URL":"http://localhost:30500/"}}'
kubectl -n genai4e-ci patch configmap ci-runner-env --type merge -p '{"data":{"GENAI4E_REGISTRY":"localhost:30500",
  "GENAI4E_REGISTRY_INSECURE":"true","GENAI4E_CI_FORWARD":"127.0.0.1:30500=forgejo.genai4e-git.svc.cluster.local:3000"}}'
kubectl apply -f k8s/overlays/dev/git-dev.yaml && kubectl -n genai4e-git delete httproute git
kubectl -n genai4e-git rollout restart statefulset/forgejo
kubectl -n genai4e-ci rollout restart deployment/ci-launcher
kubectl -n genai4e-system rollout restart deployment/control-plane
kubectl -n genai4e-system exec deployment/control-plane -- genai4e-admin ci-check   # Git, CI and the registry
```

Installs with a real hostname need none of this.

## Upgrade

Run `helm upgrade … --reuse-values --version <new>`. Each upgrade reruns the setup Jobs. They only create what is missing, and they never replace a secret.

## Uninstall

`helm uninstall genai4e -n genai4e` removes the workloads, but **keeps the namespaces**. Those hold the encryption key, the databases and the apps. A later `helm install` picks them up again. To delete everything, run `kubectl delete namespace genai4e-system genai4e-edge genai4e-git genai4e-ci genai4e-data genai4e-apps-mcp genai4e-apps-rag genai4e-apps-agent`. This can't be undone.

## Verify the images

Every image and the chart are signed with cosign by Genai4E's release workflow:

```bash
cosign verify ghcr.io/genai4e-dev/control-plane:<version> \
  --certificate-identity-regexp '^https://github.com/genai4e-dev/genai4e-platform/' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```
