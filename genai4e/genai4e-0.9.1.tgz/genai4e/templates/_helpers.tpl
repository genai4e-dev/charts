{{/* An image: (list $ "control-plane"). Ours come from images.registry with the release's tag. */}}
{{- define "genai4e.image" -}}
{{- $root := index . 0 -}}
{{- $name := index . 1 -}}
{{- $images := $root.Values.images -}}
{{- if hasKey $images $name -}}
{{- index $images $name -}}
{{- else -}}
{{- printf "%s/%s:%s" (trimSuffix "/" $images.registry) $name (default $root.Chart.AppVersion $images.tag) -}}
{{- end -}}
{{- end -}}

{{- define "genai4e.tlsMode" -}}
{{- if .Values.tls.cert -}}files{{- else -}}{{ .Values.tls.mode }}{{- end -}}
{{- end -}}

{{/* Rolls the pods when a setting changes (the license is read live, so it doesn't count). */}}
{{- define "genai4e.checksum" -}}
{{- omit .Values "license" | toJson | sha256sum | trunc 16 | quote -}}
{{- end -}}

{{- define "genai4e.clusterId" -}}
{{- if .Values.clusterId -}}
{{- .Values.clusterId -}}
{{- else -}}
{{- dig "metadata" "uid" "" (lookup "v1" "Namespace" "" "kube-system") -}}
{{- end -}}
{{- end -}}

{{- define "genai4e.checkReleaseNamespace" -}}
{{- if has .Release.Namespace (list "genai4e-system" "genai4e-edge" "genai4e-git" "genai4e-ci" "genai4e-data") -}}
{{- fail (printf "install the chart into its own namespace (e.g. -n genai4e --create-namespace), not %s: the chart creates the platform's namespaces itself" .Release.Namespace) -}}
{{- end -}}
{{- end -}}
